package com.trekmanagement.trek;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface TrekInclusionRepository extends JpaRepository<TrekInclusion, UUID> {

    List<TrekInclusion> findByTrekIdOrderByDisplayOrderAsc(UUID trekId);
}
